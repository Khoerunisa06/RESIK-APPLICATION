export interface SampahItem {
  jenis: string;
  berat: number;
  harga: number;
}